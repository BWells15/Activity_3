package base;

public class ShapeBase implements ShapeInterface{
protected String name;

protected double width, height;
	/**
	 * defines basic attriibutes
	 * @param name
	 * @param width
	 * @param height
	 */
	public ShapeBase(String name, double width, double height) {
		this.name = name;
		this.width = width;
		this.height = height;
		
	}
	/**
	 * Returns the name
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Calculates the area
	 */
	public double calculateArea(){
	return -1;
}
}
