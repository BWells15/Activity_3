package base;

public interface ShapeInterface {
	/** 
	* Calculates the area
	*/
	public double calculateArea();

}
