package shape;

import base.ShapeBase;

public class Oval extends ShapeBase{

	public Oval(String name, double width, double height) {
		super(name, width, height);
		// TODO Auto-generated constructor stub
	}
	/**
	 * Calculates the area
	 */
	@Override
	public double calculateArea() {
		return width = 3.14*width*height;
	}
}
