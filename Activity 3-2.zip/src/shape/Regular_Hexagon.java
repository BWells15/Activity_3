package shape;

import base.ShapeBase;
import java.lang.Math;

public class Regular_Hexagon extends ShapeBase {

	public Regular_Hexagon(String name, double width, double height) {
		super(name, width, height);
		// TODO Auto-generated constructor stub
	}
	/**
	 * Calculates the area
	 */
	@Override
	public double calculateArea() {
		return width = (3 * Math.sqrt(3) / 2) * Math.pow(height,2);
	}

}
