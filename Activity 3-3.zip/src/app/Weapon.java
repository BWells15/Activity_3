/**
 * 
 */
package app;

/**
 * @author blake wells
 *
 */
public interface  Weapon {
	
	public void fireWeapon();
	public void fireWeapon(int power);
	public abstract void activate(boolean enable);
}
