package app;

public class Game {
	public static void main(String[] args) {
		Weapon[] weapons = new Weapon[2];
		weapons[0] = new Bomb();
		weapons[1] = new Gun();
		
		for(int x=0; x < weapons.length; ++x) {
			fireWeapon(weapons[x]);
		}
	}
	/**
	 * takes a weapon and fires it
	 * @param weapon
	 */
	private static void fireWeapon(Weapon weapon) {
		if (weapon instanceof Bomb) {
			System.out.println("------------> I am a Bomb");
		}
		weapon.activate(true);
		weapon.fireWeapon(5);
	}
	
}
