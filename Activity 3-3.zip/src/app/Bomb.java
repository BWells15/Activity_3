package app;

/**
 * 
 * @author blake wells
 *
 */
public class Bomb implements Weapon{
	/**
	 * method that fires the weapon, takes a power
	 * @param power takes a power used in weapon
	 */
	public void fireWeapon(int power) {
		System.out.println("In Bomb.fireWeapon() with a power of " + power);
	}
	/**
	 * method that fires weapon with no parameters
	 */
	public void fireWeapon() {
		System.out.println("in overloaded Bomb.fireWeapon()");
	}
	/**
	 * method that activates the bomb
	 * @param enable boolean whether its enabled
	 */
	public void activate(boolean enable) {
		System.out.println("In the Bomb.activate() with an enable of " + enable);
	}
}
